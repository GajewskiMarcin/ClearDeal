{**
 * ClearDeal - Logs Tab Template
 *
 * @author    Marcin Gajewski <kontakt@marcingajewski.pl>
 * @copyright 2025 marcingajewski.pl
 *}

<div class="cleardeal-logs">
    {* Toolbar *}
    <div class="cleardeal-toolbar">
        <div class="cleardeal-toolbar-left">
            <span class="cleardeal-logs-count">
                {l s='Total:' mod='cleardeal'} <strong>{$logs_count}</strong> {l s='entries' mod='cleardeal'}
            </span>
        </div>
        <div class="cleardeal-toolbar-right">
            <a href="{$admin_link}&tab=logs&action=export" class="cleardeal-btn cleardeal-btn-secondary">
                <i class="material-icons">download</i>
                {l s='Export CSV' mod='cleardeal'}
            </a>
            <button type="button" class="cleardeal-btn cleardeal-btn-secondary" id="import_btn">
                <i class="material-icons">upload</i>
                {l s='Import CSV' mod='cleardeal'}
            </button>
            <a href="{$admin_link}&tab=logs&action=clean_old" class="cleardeal-btn cleardeal-btn-outline" onclick="return confirm('{l s='Are you sure you want to delete old logs?' mod='cleardeal' js=1}');">
                <i class="material-icons">delete_sweep</i>
                {l s='Clean Old Logs' mod='cleardeal'}
            </a>
        </div>
    </div>

    {* Import Form (hidden by default) *}
    <div class="cleardeal-import-form" id="import_form" style="display:none;">
        <form action="{$admin_link}&tab=logs" method="post" enctype="multipart/form-data">
            <div class="cleardeal-card">
                <div class="cleardeal-card-header">
                    <i class="material-icons">upload_file</i>
                    <h3>{l s='Import Price Logs' mod='cleardeal'}</h3>
                    <button type="button" class="cleardeal-close-btn" id="close_import">
                        <i class="material-icons">close</i>
                    </button>
                </div>
                <div class="cleardeal-card-body">
                    <div class="cleardeal-field">
                        <label>{l s='CSV File' mod='cleardeal'}</label>
                        <input type="file" name="import_file" accept=".csv" required class="cleardeal-file-input">
                        <span class="cleardeal-hint">
                            {l s='Upload a CSV file exported from ClearDeal or in compatible format.' mod='cleardeal'}
                        </span>
                    </div>
                    <button type="submit" name="submitImportCsv" class="cleardeal-btn cleardeal-btn-primary">
                        <i class="material-icons">upload</i>
                        {l s='Import' mod='cleardeal'}
                    </button>
                </div>
            </div>
        </form>
    </div>

    {* Logs Table *}
    <form action="{$admin_link}&tab=logs&action=delete_logs" method="post" id="logs_form">
        <div class="cleardeal-table-wrapper">
            <table class="cleardeal-table">
                <thead>
                    <tr>
                        <th class="cleardeal-th-check">
                            <input type="checkbox" id="check_all">
                        </th>
                        <th>{l s='ID' mod='cleardeal'}</th>
                        <th>{l s='Product' mod='cleardeal'}</th>
                        <th>{l s='Attr. ID' mod='cleardeal'}</th>
                        <th>{l s='Price (Gross)' mod='cleardeal'}</th>
                        <th>{l s='Price (Net)' mod='cleardeal'}</th>
                        <th>{l s='Currency' mod='cleardeal'}</th>
                        <th>{l s='Country' mod='cleardeal'}</th>
                        <th>{l s='Group' mod='cleardeal'}</th>
                        <th>{l s='Date' mod='cleardeal'}</th>
                    </tr>
                </thead>
                <tbody>
                    {if $logs|count > 0}
                        {foreach from=$logs item=log}
                            <tr>
                                <td class="cleardeal-td-check">
                                    <input type="checkbox" name="log_ids[]" value="{$log.id_history}">
                                </td>
                                <td class="cleardeal-td-id">{$log.id_history}</td>
                                <td class="cleardeal-td-product">
                                    <span class="cleardeal-product-id">#{$log.id_product}</span>
                                    {$log.product_name|escape:'html':'UTF-8'|truncate:40:'...'}
                                </td>
                                <td class="cleardeal-td-center">{$log.id_product_attribute}</td>
                                <td class="cleardeal-td-price">{$log.price_tax_incl|string_format:"%.2f"}</td>
                                <td class="cleardeal-td-price">{$log.price_tax_excl|string_format:"%.2f"}</td>
                                <td class="cleardeal-td-center">{$log.id_currency}</td>
                                <td class="cleardeal-td-center">{$log.id_country}</td>
                                <td class="cleardeal-td-center">{$log.id_group}</td>
                                <td class="cleardeal-td-date">{$log.captured_at|date_format:"%Y-%m-%d %H:%M"}</td>
                            </tr>
                        {/foreach}
                    {else}
                        <tr>
                            <td colspan="10" class="cleardeal-empty">
                                <i class="material-icons">inbox</i>
                                <p>{l s='No price logs found.' mod='cleardeal'}</p>
                                <span>{l s='Price history will be recorded when products are updated.' mod='cleardeal'}</span>
                            </td>
                        </tr>
                    {/if}
                </tbody>
            </table>
        </div>

        {* Pagination *}
        {if $logs_total_pages > 1}
            <div class="cleardeal-pagination">
                <div class="cleardeal-pagination-info">
                    {l s='Page' mod='cleardeal'} {$logs_page} {l s='of' mod='cleardeal'} {$logs_total_pages}
                </div>
                <div class="cleardeal-pagination-links">
                    {if $logs_page > 1}
                        <a href="{$admin_link}&tab=logs&page=1" class="cleardeal-page-link">
                            <i class="material-icons">first_page</i>
                        </a>
                        <a href="{$admin_link}&tab=logs&page={$logs_page - 1}" class="cleardeal-page-link">
                            <i class="material-icons">chevron_left</i>
                        </a>
                    {/if}

                    {for $p=max(1, $logs_page-2) to min($logs_total_pages, $logs_page+2)}
                        <a href="{$admin_link}&tab=logs&page={$p}" class="cleardeal-page-link {if $p == $logs_page}active{/if}">{$p}</a>
                    {/for}

                    {if $logs_page < $logs_total_pages}
                        <a href="{$admin_link}&tab=logs&page={$logs_page + 1}" class="cleardeal-page-link">
                            <i class="material-icons">chevron_right</i>
                        </a>
                        <a href="{$admin_link}&tab=logs&page={$logs_total_pages}" class="cleardeal-page-link">
                            <i class="material-icons">last_page</i>
                        </a>
                    {/if}
                </div>
            </div>
        {/if}

        {* Bulk Actions *}
        {if $logs|count > 0}
            <div class="cleardeal-bulk-actions">
                <button type="submit" class="cleardeal-btn cleardeal-btn-danger" onclick="return confirm('{l s='Are you sure you want to delete selected logs?' mod='cleardeal' js=1}');">
                    <i class="material-icons">delete</i>
                    {l s='Delete Selected' mod='cleardeal'}
                </button>
            </div>
        {/if}
    </form>
</div>
