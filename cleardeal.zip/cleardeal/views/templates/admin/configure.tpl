{**
 * ClearDeal - Admin Configuration Template
 *
 * @author    Marcin Gajewski <kontakt@marcingajewski.pl>
 * @copyright 2025 marcingajewski.pl
 *}

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<div class="cleardeal-panel">
    {* Header *}
    <div class="cleardeal-header">
        <div class="cleardeal-header-title">
            <h1>ClearDeal</h1>
            <span class="cleardeal-version">v{$module_version}</span>
        </div>
        <p class="cleardeal-subtitle">{l s='EU Omnibus Directive - Lowest Price Display' mod='cleardeal'}</p>
    </div>

    {* Messages *}
    {if isset($confirmations) && $confirmations|count > 0}
        {foreach from=$confirmations item=msg}
            <div class="cleardeal-alert cleardeal-alert-success">
                <i class="material-icons">check_circle</i>
                {$msg}
            </div>
        {/foreach}
    {/if}

    {if isset($errors) && $errors|count > 0}
        {foreach from=$errors item=msg}
            <div class="cleardeal-alert cleardeal-alert-error">
                <i class="material-icons">error</i>
                {$msg}
            </div>
        {/foreach}
    {/if}

    {* Tabs Navigation *}
    <div class="cleardeal-tabs">
        <a href="{$admin_link}&tab=settings" class="cleardeal-tab {if $current_tab == 'settings'}active{/if}">
            <i class="material-icons">settings</i>
            {l s='Settings' mod='cleardeal'}
        </a>
        <a href="{$admin_link}&tab=logs" class="cleardeal-tab {if $current_tab == 'logs'}active{/if}">
            <i class="material-icons">history</i>
            {l s='Price Logs' mod='cleardeal'}
            <span class="cleardeal-badge">{$logs_count}</span>
        </a>
        <a href="{$admin_link}&tab=support" class="cleardeal-tab {if $current_tab == 'support'}active{/if}">
            <i class="material-icons">favorite</i>
            {l s='Support' mod='cleardeal'}
        </a>
    </div>

    {* Tab Content *}
    <div class="cleardeal-content">
        {if $current_tab == 'settings'}
            {include file="./settings_tab.tpl"}
        {elseif $current_tab == 'logs'}
            {include file="./logs_tab.tpl"}
        {elseif $current_tab == 'support'}
            {include file="./support_tab.tpl"}
        {/if}
    </div>
</div>

<script>
    var cleardeal_languages = {json_encode($languages)};
    var cleardeal_default_lang = {$default_lang};
    var cleardeal_current_lang = {$current_lang};
</script>
