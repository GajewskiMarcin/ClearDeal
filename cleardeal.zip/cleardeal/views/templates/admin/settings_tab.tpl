{**
 * ClearDeal - Settings Tab Template
 *
 * @author    Marcin Gajewski <kontakt@marcingajewski.pl>
 * @copyright 2025 marcingajewski.pl
 *}

<form action="{$admin_link}&tab=settings" method="post" enctype="multipart/form-data" class="cleardeal-form">

    {* Display Settings *}
    <div class="cleardeal-card">
        <div class="cleardeal-card-header">
            <i class="material-icons">visibility</i>
            <h3>{l s='Display Settings' mod='cleardeal'}</h3>
        </div>
        <div class="cleardeal-card-body">
            <div class="cleardeal-row">
                <div class="cleardeal-field">
                    <label>{l s='Number of days to analyze' mod='cleardeal'}</label>
                    <input type="number" name="CLEARDEAL_DAYS" value="{$settings.CLEARDEAL_DAYS|escape:'html':'UTF-8'}" min="1" max="365" class="cleardeal-input cleardeal-input-sm">
                    <span class="cleardeal-hint">{l s='Default: 30 days (EU Omnibus requirement)' mod='cleardeal'}</span>
                </div>

                <div class="cleardeal-field">
                    <label>{l s='Display mode' mod='cleardeal'}</label>
                    <select name="CLEARDEAL_DISPLAY_MODE" class="cleardeal-select">
                        <option value="always" {if $settings.CLEARDEAL_DISPLAY_MODE == 'always'}selected{/if}>{l s='Always show' mod='cleardeal'}</option>
                        <option value="on-discount" {if $settings.CLEARDEAL_DISPLAY_MODE == 'on-discount'}selected{/if}>{l s='Only when product is discounted' mod='cleardeal'}</option>
                    </select>
                </div>

                <div class="cleardeal-field">
                    <label>{l s='Price type' mod='cleardeal'}</label>
                    <select name="CLEARDEAL_PRICE_TYPE" class="cleardeal-select">
                        <option value="gross" {if $settings.CLEARDEAL_PRICE_TYPE == 'gross'}selected{/if}>{l s='Gross (with tax)' mod='cleardeal'}</option>
                        <option value="net" {if $settings.CLEARDEAL_PRICE_TYPE == 'net'}selected{/if}>{l s='Net (without tax)' mod='cleardeal'}</option>
                    </select>
                </div>
            </div>

            <div class="cleardeal-row">
                <div class="cleardeal-field">
                    <label>{l s='Show percentage change' mod='cleardeal'}</label>
                    <label class="cleardeal-switch">
                        <input type="checkbox" name="CLEARDEAL_SHOW_PERCENT" value="1" {if $settings.CLEARDEAL_SHOW_PERCENT}checked{/if}>
                        <span class="cleardeal-switch-slider"></span>
                    </label>
                </div>

                <div class="cleardeal-field">
                    <label>{l s='Percentage decimal places' mod='cleardeal'}</label>
                    <input type="number" name="CLEARDEAL_PRECISION" value="{$settings.CLEARDEAL_PRECISION|escape:'html':'UTF-8'}" min="0" max="4" class="cleardeal-input cleardeal-input-xs">
                </div>
            </div>
        </div>
    </div>

    {* Labels *}
    <div class="cleardeal-card">
        <div class="cleardeal-card-header">
            <i class="material-icons">label</i>
            <h3>{l s='Labels' mod='cleardeal'}</h3>
            <div class="cleardeal-lang-switcher">
                {foreach from=$languages item=lang}
                    <button type="button" class="cleardeal-lang-btn {if $lang.id_lang == $default_lang}active{/if}" data-lang="{$lang.id_lang}">
                        {$lang.iso_code|upper}
                    </button>
                {/foreach}
            </div>
        </div>
        <div class="cleardeal-card-body">
            <p class="cleardeal-info">
                <i class="material-icons">info</i>
                {l s='Use %s to insert the number of days. Example: "Lowest price in last %s days:"' mod='cleardeal'}
            </p>

            <div class="cleardeal-field">
                <label>{l s='Product page label' mod='cleardeal'}</label>
                {foreach from=$languages item=lang}
                    <input type="text"
                           name="CLEARDEAL_LABEL_PRODUCT_{$lang.id_lang}"
                           value="{$settings.CLEARDEAL_LABEL_PRODUCT[$lang.id_lang]|escape:'html':'UTF-8'}"
                           class="cleardeal-input cleardeal-lang-input"
                           data-lang="{$lang.id_lang}"
                           {if $lang.id_lang != $default_lang}style="display:none;"{/if}>
                {/foreach}
            </div>

            <div class="cleardeal-field">
                <label>{l s='Listing label' mod='cleardeal'}</label>
                {foreach from=$languages item=lang}
                    <input type="text"
                           name="CLEARDEAL_LABEL_LISTING_{$lang.id_lang}"
                           value="{$settings.CLEARDEAL_LABEL_LISTING[$lang.id_lang]|escape:'html':'UTF-8'}"
                           class="cleardeal-input cleardeal-lang-input"
                           data-lang="{$lang.id_lang}"
                           {if $lang.id_lang != $default_lang}style="display:none;"{/if}>
                {/foreach}
            </div>

            <div class="cleardeal-field">
                <label>{l s='Quick view label' mod='cleardeal'}</label>
                {foreach from=$languages item=lang}
                    <input type="text"
                           name="CLEARDEAL_LABEL_QUICKVIEW_{$lang.id_lang}"
                           value="{$settings.CLEARDEAL_LABEL_QUICKVIEW[$lang.id_lang]|escape:'html':'UTF-8'}"
                           class="cleardeal-input cleardeal-lang-input"
                           data-lang="{$lang.id_lang}"
                           {if $lang.id_lang != $default_lang}style="display:none;"{/if}>
                {/foreach}
            </div>
        </div>
    </div>

    {* Icon Settings *}
    <div class="cleardeal-card">
        <div class="cleardeal-card-header">
            <i class="material-icons">image</i>
            <h3>{l s='Icon Settings' mod='cleardeal'}</h3>
        </div>
        <div class="cleardeal-card-body">
            <div class="cleardeal-row">
                <div class="cleardeal-field">
                    <label>{l s='Show icon' mod='cleardeal'}</label>
                    <label class="cleardeal-switch">
                        <input type="checkbox" name="CLEARDEAL_SHOW_ICON" value="1" {if $settings.CLEARDEAL_SHOW_ICON}checked{/if} id="show_icon_toggle">
                        <span class="cleardeal-switch-slider"></span>
                    </label>
                </div>

                <div class="cleardeal-field icon-options" {if !$settings.CLEARDEAL_SHOW_ICON}style="display:none;"{/if}>
                    <label>{l s='Icon position' mod='cleardeal'}</label>
                    <select name="CLEARDEAL_ICON_POSITION" class="cleardeal-select">
                        <option value="start" {if $settings.CLEARDEAL_ICON_POSITION == 'start'}selected{/if}>{l s='Before text' mod='cleardeal'}</option>
                        <option value="end" {if $settings.CLEARDEAL_ICON_POSITION == 'end'}selected{/if}>{l s='After text' mod='cleardeal'}</option>
                    </select>
                </div>
            </div>

            <div class="icon-options" {if !$settings.CLEARDEAL_SHOW_ICON}style="display:none;"{/if}>
                <div class="cleardeal-field">
                    <label>{l s='Icon type' mod='cleardeal'}</label>
                    <div class="cleardeal-radio-group">
                        <label class="cleardeal-radio">
                            <input type="radio" name="CLEARDEAL_ICON_TYPE" value="material" {if $settings.CLEARDEAL_ICON_TYPE == 'material'}checked{/if}>
                            <span class="cleardeal-radio-mark"></span>
                            {l s='Material Icons' mod='cleardeal'}
                        </label>
                        <label class="cleardeal-radio">
                            <input type="radio" name="CLEARDEAL_ICON_TYPE" value="file" {if $settings.CLEARDEAL_ICON_TYPE == 'file'}checked{/if}>
                            <span class="cleardeal-radio-mark"></span>
                            {l s='Custom image' mod='cleardeal'}
                        </label>
                    </div>
                </div>

                <div class="cleardeal-field icon-material-options" {if $settings.CLEARDEAL_ICON_TYPE != 'material'}style="display:none;"{/if}>
                    <label>{l s='Icon name' mod='cleardeal'}</label>
                    <div class="cleardeal-input-with-preview">
                        <input type="text" name="CLEARDEAL_ICON_CLASS" value="{$settings.CLEARDEAL_ICON_CLASS|escape:'html':'UTF-8'}" class="cleardeal-input" placeholder="info">
                        <span class="cleardeal-icon-preview">
                            <i class="material-icons" id="icon_preview">{$settings.CLEARDEAL_ICON_CLASS|escape:'html':'UTF-8'}</i>
                        </span>
                    </div>
                    <span class="cleardeal-hint">
                        {l s='See available icons at' mod='cleardeal'} <a href="https://fonts.google.com/icons" target="_blank">fonts.google.com/icons</a>
                    </span>
                </div>

                <div class="cleardeal-field icon-file-options" {if $settings.CLEARDEAL_ICON_TYPE != 'file'}style="display:none;"{/if}>
                    <label>{l s='Upload icon image' mod='cleardeal'}</label>
                    <input type="file" name="CLEARDEAL_ICON_IMAGE" accept="image/*" class="cleardeal-file-input">
                    {if $settings.CLEARDEAL_ICON_IMAGE}
                        <div class="cleardeal-current-icon">
                            <img src="{$module_dir}views/img/{$settings.CLEARDEAL_ICON_IMAGE}" alt="Current icon">
                            <label class="cleardeal-checkbox">
                                <input type="checkbox" name="delete_icon" value="1">
                                <span>{l s='Delete current icon' mod='cleardeal'}</span>
                            </label>
                        </div>
                    {/if}
                </div>

                <div class="cleardeal-field">
                    <label>{l s='Tooltip text' mod='cleardeal'}</label>
                    {foreach from=$languages item=lang}
                        <textarea name="CLEARDEAL_ICON_TOOLTIP_{$lang.id_lang}"
                                  class="cleardeal-textarea cleardeal-lang-input"
                                  data-lang="{$lang.id_lang}"
                                  rows="2"
                                  {if $lang.id_lang != $default_lang}style="display:none;"{/if}>{$settings.CLEARDEAL_ICON_TOOLTIP[$lang.id_lang]|escape:'html':'UTF-8'}</textarea>
                    {/foreach}
                    <span class="cleardeal-hint">{l s='Appears when hovering over the icon. Use %s for days.' mod='cleardeal'}</span>
                </div>
            </div>
        </div>
    </div>

    {* Advanced Settings *}
    <div class="cleardeal-card">
        <div class="cleardeal-card-header">
            <i class="material-icons">tune</i>
            <h3>{l s='Advanced Settings' mod='cleardeal'}</h3>
        </div>
        <div class="cleardeal-card-body">
            <div class="cleardeal-row">
                <div class="cleardeal-field">
                    <label>{l s='Price logging mode' mod='cleardeal'}</label>
                    <select name="CLEARDEAL_LOGGING_MODE" class="cleardeal-select">
                        <option value="immediate" {if $settings.CLEARDEAL_LOGGING_MODE == 'immediate'}selected{/if}>{l s='Immediate (on product update)' mod='cleardeal'}</option>
                        <option value="cron" {if $settings.CLEARDEAL_LOGGING_MODE == 'cron'}selected{/if}>{l s='CRON job only' mod='cleardeal'}</option>
                    </select>
                </div>

                <div class="cleardeal-field">
                    <label>{l s='Log retention (days)' mod='cleardeal'}</label>
                    <input type="number" name="CLEARDEAL_LOG_RETENTION" value="{$settings.CLEARDEAL_LOG_RETENTION|escape:'html':'UTF-8'}" min="30" max="3650" class="cleardeal-input cleardeal-input-sm">
                    <span class="cleardeal-hint">{l s='Logs older than this will be automatically deleted' mod='cleardeal'}</span>
                </div>
            </div>
        </div>
    </div>

    {* Footer Actions *}
    <div class="cleardeal-footer">
        <button type="submit" name="submitClearDealSettings" class="cleardeal-btn cleardeal-btn-primary">
            <i class="material-icons">save</i>
            {l s='Save Settings' mod='cleardeal'}
        </button>
    </div>
</form>
