{**
 * ClearDeal - Support Tab Template
 *
 * @author    Marcin Gajewski <kontakt@marcingajewski.pl>
 * @copyright 2025 marcingajewski.pl
 *}

<div class="cleardeal-support">
    <div class="cleardeal-support-hero">
        <i class="material-icons cleardeal-heart-icon">favorite</i>
        <h2>{l s='Support the Development' mod='cleardeal'}</h2>
        <p class="cleardeal-support-lead">
            {l s='ClearDeal is free and open source. If you find it useful, consider supporting its continued development.' mod='cleardeal'}
        </p>
    </div>

    <div class="cleardeal-support-grid">
        <div class="cleardeal-support-card">
            <i class="material-icons">star</i>
            <h3>{l s='Rate & Review' mod='cleardeal'}</h3>
            <p>{l s='Leave a positive review to help others discover this module.' mod='cleardeal'}</p>
            <a href="https://addons.prestashop.com" target="_blank" class="cleardeal-btn cleardeal-btn-secondary">
                {l s='Write a Review' mod='cleardeal'}
            </a>
        </div>

        <div class="cleardeal-support-card">
            <i class="material-icons">coffee</i>
            <h3>{l s='Buy Me a Coffee' mod='cleardeal'}</h3>
            <p>{l s='A small contribution helps keep this project alive and maintained.' mod='cleardeal'}</p>
            <a href="https://www.buymeacoffee.com/marcingajewski" target="_blank" class="cleardeal-btn cleardeal-btn-primary">
                {l s='Support via Coffee' mod='cleardeal'}
            </a>
        </div>

        <div class="cleardeal-support-card">
            <i class="material-icons">bug_report</i>
            <h3>{l s='Report Issues' mod='cleardeal'}</h3>
            <p>{l s='Found a bug or have a feature request? Let me know!' mod='cleardeal'}</p>
            <a href="mailto:kontakt@marcingajewski.pl" class="cleardeal-btn cleardeal-btn-outline">
                {l s='Contact Support' mod='cleardeal'}
            </a>
        </div>
    </div>

    <div class="cleardeal-support-footer">
        <p>
            <strong>ClearDeal v{$module_version}</strong><br>
            {l s='Created by' mod='cleardeal'} <a href="https://marcingajewski.pl" target="_blank">marcingajewski.pl</a><br>
            {l s='Compatible with PrestaShop 8.x and 9.x' mod='cleardeal'}
        </p>
    </div>
</div>
