/**
 * ClearDeal - Admin JavaScript
 *
 * @author    Marcin Gajewski <kontakt@marcingajewski.pl>
 * @copyright 2025 marcingajewski.pl
 */

document.addEventListener('DOMContentLoaded', function() {
    // =========================================================================
    // Language Switcher
    // =========================================================================
    const langButtons = document.querySelectorAll('.cleardeal-lang-btn');
    const langInputs = document.querySelectorAll('.cleardeal-lang-input');

    langButtons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            const langId = this.getAttribute('data-lang');

            // Update active button
            langButtons.forEach(function(b) {
                b.classList.remove('active');
            });
            this.classList.add('active');

            // Show/hide language inputs
            langInputs.forEach(function(input) {
                if (input.getAttribute('data-lang') === langId) {
                    input.style.display = '';
                } else {
                    input.style.display = 'none';
                }
            });
        });
    });

    // =========================================================================
    // Icon Settings Toggle
    // =========================================================================
    const showIconToggle = document.getElementById('show_icon_toggle');
    const iconOptions = document.querySelectorAll('.icon-options');

    if (showIconToggle) {
        showIconToggle.addEventListener('change', function() {
            iconOptions.forEach(function(el) {
                el.style.display = showIconToggle.checked ? '' : 'none';
            });
        });
    }

    // =========================================================================
    // Icon Type Toggle
    // =========================================================================
    const iconTypeRadios = document.querySelectorAll('input[name="CLEARDEAL_ICON_TYPE"]');
    const materialOptions = document.querySelectorAll('.icon-material-options');
    const fileOptions = document.querySelectorAll('.icon-file-options');

    iconTypeRadios.forEach(function(radio) {
        radio.addEventListener('change', function() {
            const isMaterial = this.value === 'material';

            materialOptions.forEach(function(el) {
                el.style.display = isMaterial ? '' : 'none';
            });

            fileOptions.forEach(function(el) {
                el.style.display = isMaterial ? 'none' : '';
            });
        });
    });

    // =========================================================================
    // Icon Preview
    // =========================================================================
    const iconClassInput = document.querySelector('input[name="CLEARDEAL_ICON_CLASS"]');
    const iconPreview = document.getElementById('icon_preview');

    if (iconClassInput && iconPreview) {
        iconClassInput.addEventListener('input', function() {
            iconPreview.textContent = this.value || 'info';
        });
    }

    // =========================================================================
    // Import Form Toggle
    // =========================================================================
    const importBtn = document.getElementById('import_btn');
    const importForm = document.getElementById('import_form');
    const closeImport = document.getElementById('close_import');

    if (importBtn && importForm) {
        importBtn.addEventListener('click', function() {
            importForm.style.display = importForm.style.display === 'none' ? '' : 'none';
        });
    }

    if (closeImport && importForm) {
        closeImport.addEventListener('click', function() {
            importForm.style.display = 'none';
        });
    }

    // =========================================================================
    // Check All Checkbox
    // =========================================================================
    const checkAll = document.getElementById('check_all');
    const logCheckboxes = document.querySelectorAll('input[name="log_ids[]"]');

    if (checkAll) {
        checkAll.addEventListener('change', function() {
            const isChecked = this.checked;
            logCheckboxes.forEach(function(cb) {
                cb.checked = isChecked;
            });
        });
    }

    // Update "check all" when individual checkboxes change
    logCheckboxes.forEach(function(cb) {
        cb.addEventListener('change', function() {
            const allChecked = Array.from(logCheckboxes).every(function(c) {
                return c.checked;
            });
            const someChecked = Array.from(logCheckboxes).some(function(c) {
                return c.checked;
            });

            if (checkAll) {
                checkAll.checked = allChecked;
                checkAll.indeterminate = someChecked && !allChecked;
            }
        });
    });
});
