<?php
/**
 * ClearDeal - EU Omnibus Directive Compliance
 *
 * Admin Controller - handles settings and logs
 *
 * @author    Marcin Gajewski <kontakt@marcingajewski.pl>
 * @copyright 2025 marcingajewski.pl
 * @license   https://marcingajewski.pl
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once _PS_MODULE_DIR_ . 'cleardeal/classes/ClearDealPriceHistory.php';

class AdminClearDealController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function init()
    {
        parent::init();

        // Handle AJAX requests
        if (Tools::getValue('ajax')) {
            $this->ajax = true;
        }
    }

    public function initContent()
    {
        parent::initContent();

        // Handle actions
        $this->processActions();

        // Add CSS and JS
        $this->addCSS($this->module->getPathUri() . 'views/css/admin.css');
        $this->addJS($this->module->getPathUri() . 'views/js/admin.js');

        // Get current tab
        $current_tab = Tools::getValue('tab', 'settings');

        // Get logs for logs tab
        $logs = [];
        $logs_count = 0;
        $current_page = 1;
        $per_page = 50;

        if ($current_tab === 'logs') {
            $current_page = max(1, (int) Tools::getValue('page', 1));
            $logs = ClearDealPriceHistory::getLogs($current_page, $per_page);
            $logs_count = ClearDealPriceHistory::getLogsCount();
        }

        // Assign template variables
        $this->context->smarty->assign([
            'module_dir' => $this->module->getPathUri(),
            'module_version' => $this->module->version,
            'current_tab' => $current_tab,
            'settings' => $this->getConfigValues(),
            'languages' => Language::getLanguages(false),
            'default_lang' => (int) Configuration::get('PS_LANG_DEFAULT'),
            'current_lang' => (int) $this->context->language->id,
            'logs' => $logs,
            'logs_count' => $logs_count,
            'logs_page' => $current_page,
            'logs_per_page' => $per_page,
            'logs_total_pages' => ceil($logs_count / $per_page),
            'admin_link' => $this->context->link->getAdminLink('AdminClearDeal'),
            'token' => $this->token,
        ]);

        $this->setTemplate('configure.tpl');
    }

    protected function processActions()
    {
        // Save settings
        if (Tools::isSubmit('submitClearDealSettings')) {
            $this->processSaveSettings();
        }

        // Export CSV
        if (Tools::getValue('action') === 'export') {
            $this->processExport();
        }

        // Import CSV
        if (Tools::isSubmit('submitImportCsv')) {
            $this->processImport();
        }

        // Delete logs
        if (Tools::getValue('action') === 'delete_logs') {
            $this->processDeleteLogs();
        }

        // Clean old logs
        if (Tools::getValue('action') === 'clean_old') {
            $this->processCleanOldLogs();
        }
    }

    protected function processSaveSettings()
    {
        $languages = Language::getLanguages(false);

        // Basic settings
        Configuration::updateValue('CLEARDEAL_DAYS', (int) Tools::getValue('CLEARDEAL_DAYS', 30));
        Configuration::updateValue('CLEARDEAL_DISPLAY_MODE', pSQL(Tools::getValue('CLEARDEAL_DISPLAY_MODE', 'on-discount')));
        Configuration::updateValue('CLEARDEAL_PRICE_TYPE', pSQL(Tools::getValue('CLEARDEAL_PRICE_TYPE', 'gross')));
        Configuration::updateValue('CLEARDEAL_SHOW_PERCENT', (int) Tools::getValue('CLEARDEAL_SHOW_PERCENT', 1));
        Configuration::updateValue('CLEARDEAL_PRECISION', (int) Tools::getValue('CLEARDEAL_PRECISION', 0));

        // Icon settings
        Configuration::updateValue('CLEARDEAL_SHOW_ICON', (int) Tools::getValue('CLEARDEAL_SHOW_ICON', 1));
        Configuration::updateValue('CLEARDEAL_ICON_POSITION', pSQL(Tools::getValue('CLEARDEAL_ICON_POSITION', 'start')));
        Configuration::updateValue('CLEARDEAL_ICON_TYPE', pSQL(Tools::getValue('CLEARDEAL_ICON_TYPE', 'material')));
        Configuration::updateValue('CLEARDEAL_ICON_CLASS', pSQL(Tools::getValue('CLEARDEAL_ICON_CLASS', 'info')));

        // Handle icon image upload
        if (isset($_FILES['CLEARDEAL_ICON_IMAGE']) && !empty($_FILES['CLEARDEAL_ICON_IMAGE']['tmp_name'])) {
            $ext = pathinfo($_FILES['CLEARDEAL_ICON_IMAGE']['name'], PATHINFO_EXTENSION);
            $allowed = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp'];

            if (in_array(strtolower($ext), $allowed)) {
                $file_name = 'icon_' . md5(time()) . '.' . $ext;
                $dest = _PS_MODULE_DIR_ . 'cleardeal/views/img/' . $file_name;

                if (move_uploaded_file($_FILES['CLEARDEAL_ICON_IMAGE']['tmp_name'], $dest)) {
                    // Delete old icon
                    $old_icon = Configuration::get('CLEARDEAL_ICON_IMAGE');
                    if ($old_icon && file_exists(_PS_MODULE_DIR_ . 'cleardeal/views/img/' . $old_icon)) {
                        unlink(_PS_MODULE_DIR_ . 'cleardeal/views/img/' . $old_icon);
                    }
                    Configuration::updateValue('CLEARDEAL_ICON_IMAGE', $file_name);
                }
            }
        }

        // Delete icon
        if (Tools::getValue('delete_icon')) {
            $old_icon = Configuration::get('CLEARDEAL_ICON_IMAGE');
            if ($old_icon && file_exists(_PS_MODULE_DIR_ . 'cleardeal/views/img/' . $old_icon)) {
                unlink(_PS_MODULE_DIR_ . 'cleardeal/views/img/' . $old_icon);
            }
            Configuration::updateValue('CLEARDEAL_ICON_IMAGE', '');
        }

        // Multilingual labels
        $label_product = [];
        $label_listing = [];
        $label_quickview = [];
        $tooltip = [];

        foreach ($languages as $lang) {
            $id = (int) $lang['id_lang'];
            $label_product[$id] = Tools::getValue('CLEARDEAL_LABEL_PRODUCT_' . $id, '');
            $label_listing[$id] = Tools::getValue('CLEARDEAL_LABEL_LISTING_' . $id, '');
            $label_quickview[$id] = Tools::getValue('CLEARDEAL_LABEL_QUICKVIEW_' . $id, '');
            $tooltip[$id] = Tools::getValue('CLEARDEAL_ICON_TOOLTIP_' . $id, '');
        }

        Configuration::updateValue('CLEARDEAL_LABEL_PRODUCT', $label_product);
        Configuration::updateValue('CLEARDEAL_LABEL_LISTING', $label_listing);
        Configuration::updateValue('CLEARDEAL_LABEL_QUICKVIEW', $label_quickview);
        Configuration::updateValue('CLEARDEAL_ICON_TOOLTIP', $tooltip);

        // Advanced settings
        Configuration::updateValue('CLEARDEAL_LOGGING_MODE', pSQL(Tools::getValue('CLEARDEAL_LOGGING_MODE', 'immediate')));
        Configuration::updateValue('CLEARDEAL_LOG_RETENTION', (int) Tools::getValue('CLEARDEAL_LOG_RETENTION', 365));

        $this->confirmations[] = $this->l('Settings saved successfully.');
    }

    protected function processExport()
    {
        $csv = ClearDealPriceHistory::exportToCsv();

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="cleardeal_logs_' . date('Y-m-d') . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Add BOM for Excel UTF-8 compatibility
        echo "\xEF\xBB\xBF";
        echo $csv;
        exit;
    }

    protected function processImport()
    {
        if (!isset($_FILES['import_file']) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
            $this->errors[] = $this->l('Error uploading file.');
            return;
        }

        $imported = ClearDealPriceHistory::importFromCsv($_FILES['import_file']['tmp_name']);

        $this->confirmations[] = sprintf($this->l('Successfully imported %d log entries.'), $imported);
    }

    protected function processDeleteLogs()
    {
        $ids = Tools::getValue('log_ids', []);

        if (empty($ids)) {
            $this->errors[] = $this->l('No logs selected.');
            return;
        }

        if (ClearDealPriceHistory::deleteByIds($ids)) {
            $this->confirmations[] = sprintf($this->l('Deleted %d log entries.'), count($ids));
        } else {
            $this->errors[] = $this->l('Error deleting logs.');
        }
    }

    protected function processCleanOldLogs()
    {
        $days = (int) Configuration::get('CLEARDEAL_LOG_RETENTION') ?: 365;

        if (ClearDealPriceHistory::cleanOldLogs($days)) {
            $this->confirmations[] = sprintf($this->l('Deleted logs older than %d days.'), $days);
        } else {
            $this->errors[] = $this->l('Error cleaning old logs.');
        }
    }

    protected function getConfigValues()
    {
        $languages = Language::getLanguages(false);

        $values = [
            'CLEARDEAL_DAYS' => Configuration::get('CLEARDEAL_DAYS') ?: 30,
            'CLEARDEAL_DISPLAY_MODE' => Configuration::get('CLEARDEAL_DISPLAY_MODE') ?: 'on-discount',
            'CLEARDEAL_PRICE_TYPE' => Configuration::get('CLEARDEAL_PRICE_TYPE') ?: 'gross',
            'CLEARDEAL_SHOW_PERCENT' => Configuration::get('CLEARDEAL_SHOW_PERCENT'),
            'CLEARDEAL_PRECISION' => Configuration::get('CLEARDEAL_PRECISION') ?: 0,
            'CLEARDEAL_SHOW_ICON' => Configuration::get('CLEARDEAL_SHOW_ICON'),
            'CLEARDEAL_ICON_POSITION' => Configuration::get('CLEARDEAL_ICON_POSITION') ?: 'start',
            'CLEARDEAL_ICON_TYPE' => Configuration::get('CLEARDEAL_ICON_TYPE') ?: 'material',
            'CLEARDEAL_ICON_CLASS' => Configuration::get('CLEARDEAL_ICON_CLASS') ?: 'info',
            'CLEARDEAL_ICON_IMAGE' => Configuration::get('CLEARDEAL_ICON_IMAGE') ?: '',
            'CLEARDEAL_LOGGING_MODE' => Configuration::get('CLEARDEAL_LOGGING_MODE') ?: 'immediate',
            'CLEARDEAL_LOG_RETENTION' => Configuration::get('CLEARDEAL_LOG_RETENTION') ?: 365,
        ];

        // Multilingual values
        foreach ($languages as $lang) {
            $id = (int) $lang['id_lang'];
            $values['CLEARDEAL_LABEL_PRODUCT'][$id] = Configuration::get('CLEARDEAL_LABEL_PRODUCT', $id) ?: '';
            $values['CLEARDEAL_LABEL_LISTING'][$id] = Configuration::get('CLEARDEAL_LABEL_LISTING', $id) ?: '';
            $values['CLEARDEAL_LABEL_QUICKVIEW'][$id] = Configuration::get('CLEARDEAL_LABEL_QUICKVIEW', $id) ?: '';
            $values['CLEARDEAL_ICON_TOOLTIP'][$id] = Configuration::get('CLEARDEAL_ICON_TOOLTIP', $id) ?: '';
        }

        return $values;
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);

        // Add Material Icons
        $this->addCSS('https://fonts.googleapis.com/icon?family=Material+Icons');
    }
}
