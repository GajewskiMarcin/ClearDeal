<?php
/**
 * ClearDeal - Creative Elements Widget
 *
 * Full styling options for page builder users
 *
 * @author    Marcin Gajewski <kontakt@marcingajewski.pl>
 * @copyright 2025 marcingajewski.pl
 */

namespace ClearDeal\Widget;

use CE\WidgetBase;
use CE\ControlsManager;

if (!defined('_PS_VERSION_')) {
    exit;
}

class WidgetClearDeal extends WidgetBase
{
    const REMOTE_RENDER = true;

    public function l($string)
    {
        return \Translate::getModuleTranslation('cleardeal', $string, 'widgetcleardeal');
    }

    public function getName()
    {
        return 'cleardeal';
    }

    public function getTitle()
    {
        return 'ClearDeal';
    }

    public function getIcon()
    {
        return 'eicon-price-tag';
    }

    public function getCategories()
    {
        return ['secretsauce'];
    }

    protected function _registerControls()
    {
        // =====================================================================
        // CONTENT SECTION
        // =====================================================================
        $this->startControlsSection(
            'section_content',
            [
                'label' => $this->l('Settings'),
            ]
        );

        $this->addControl(
            'days',
            [
                'label' => $this->l('Days'),
                'type' => ControlsManager::NUMBER,
                'default' => 30,
                'min' => 1,
                'max' => 365,
            ]
        );

        $this->addControl(
            'display_mode',
            [
                'label' => $this->l('Display Mode'),
                'type' => ControlsManager::SELECT,
                'options' => [
                    'default' => $this->l('Module Default'),
                    'always' => $this->l('Always'),
                    'on-discount' => $this->l('Only when discounted'),
                ],
                'default' => 'default',
            ]
        );

        $this->addControl(
            'price_type',
            [
                'label' => $this->l('Price Type'),
                'type' => ControlsManager::SELECT,
                'options' => [
                    'default' => $this->l('Module Default'),
                    'gross' => $this->l('Gross (with tax)'),
                    'net' => $this->l('Net (without tax)'),
                ],
                'default' => 'default',
            ]
        );

        $this->addControl(
            'show_percent',
            [
                'label' => $this->l('Show Percentage'),
                'type' => ControlsManager::SELECT,
                'options' => [
                    'default' => $this->l('Module Default'),
                    'yes' => $this->l('Yes'),
                    'no' => $this->l('No'),
                ],
                'default' => 'default',
            ]
        );

        $this->addControl(
            'show_icon',
            [
                'label' => $this->l('Show Icon'),
                'type' => ControlsManager::SELECT,
                'options' => [
                    'default' => $this->l('Module Default'),
                    'yes' => $this->l('Yes'),
                    'no' => $this->l('No'),
                ],
                'default' => 'default',
            ]
        );

        $this->addControl(
            'icon_position',
            [
                'label' => $this->l('Icon Position'),
                'type' => ControlsManager::SELECT,
                'options' => [
                    'start' => $this->l('Before text'),
                    'end' => $this->l('After text'),
                ],
                'default' => 'start',
                'condition' => [
                    'show_icon' => 'yes',
                ],
            ]
        );

        $this->addControl(
            'icon_type',
            [
                'label' => $this->l('Icon Type'),
                'type' => ControlsManager::SELECT,
                'options' => [
                    'default' => $this->l('Module Default'),
                    'material' => $this->l('Material Icon'),
                    'file' => $this->l('Custom Image'),
                ],
                'default' => 'default',
                'condition' => [
                    'show_icon' => 'yes',
                ],
            ]
        );

        $this->addControl(
            'icon_class',
            [
                'label' => $this->l('Icon Name'),
                'type' => ControlsManager::TEXT,
                'default' => 'info',
                'description' => $this->l('Material Icons name (e.g., info, history, local_offer)'),
                'condition' => [
                    'show_icon' => 'yes',
                    'icon_type' => 'material',
                ],
            ]
        );

        $this->addControl(
            'icon_image',
            [
                'label' => $this->l('Icon Image'),
                'type' => ControlsManager::MEDIA,
                'condition' => [
                    'show_icon' => 'yes',
                    'icon_type' => 'file',
                ],
            ]
        );

        $this->addControl(
            'custom_label',
            [
                'label' => $this->l('Custom Label'),
                'type' => ControlsManager::TEXT,
                'description' => $this->l('Use %s for days. Leave empty for module default.'),
            ]
        );

        $this->addControl(
            'tooltip_text',
            [
                'label' => $this->l('Tooltip Text'),
                'type' => ControlsManager::TEXTAREA,
                'rows' => 3,
                'description' => $this->l('Appears when hovering the icon. Use %s for days.'),
            ]
        );

        $this->addResponsiveControl(
            'alignment',
            [
                'label' => $this->l('Alignment'),
                'type' => ControlsManager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => $this->l('Left'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => $this->l('Center'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => $this->l('Right'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-wrapper' => 'display: flex; justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->endControlsSection();

        // =====================================================================
        // STYLE SECTION: CONTAINER
        // =====================================================================
        $this->startControlsSection(
            'section_style_container',
            [
                'label' => $this->l('Container'),
                'tab' => ControlsManager::TAB_STYLE,
            ]
        );

        $this->addGroupControl(
            \CE\GroupControlBackground::getType(),
            [
                'name' => 'container_background',
                'selector' => '{{WRAPPER}} .cleardeal-widget-content',
            ]
        );

        $this->addGroupControl(
            \CE\GroupControlBorder::getType(),
            [
                'name' => 'container_border',
                'selector' => '{{WRAPPER}} .cleardeal-widget-content',
            ]
        );

        $this->addControl(
            'container_border_radius',
            [
                'label' => $this->l('Border Radius'),
                'type' => ControlsManager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->addGroupControl(
            \CE\GroupControlBoxShadow::getType(),
            [
                'name' => 'container_box_shadow',
                'selector' => '{{WRAPPER}} .cleardeal-widget-content',
            ]
        );

        $this->addResponsiveControl(
            'container_padding',
            [
                'label' => $this->l('Padding'),
                'type' => ControlsManager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->addResponsiveControl(
            'elements_gap',
            [
                'label' => $this->l('Elements Gap'),
                'type' => ControlsManager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-content' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->endControlsSection();

        // =====================================================================
        // STYLE SECTION: TYPOGRAPHY
        // =====================================================================
        $this->startControlsSection(
            'section_style_typography',
            [
                'label' => $this->l('Typography'),
                'tab' => ControlsManager::TAB_STYLE,
            ]
        );

        // Label
        $this->addControl(
            'heading_label',
            [
                'label' => $this->l('Label'),
                'type' => ControlsManager::HEADING,
            ]
        );

        $this->addControl(
            'label_color',
            [
                'label' => $this->l('Color'),
                'type' => ControlsManager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->addGroupControl(
            \CE\GroupControlTypography::getType(),
            [
                'name' => 'label_typography',
                'selector' => '{{WRAPPER}} .cleardeal-widget-label',
            ]
        );

        // Price
        $this->addControl(
            'heading_price',
            [
                'label' => $this->l('Price'),
                'type' => ControlsManager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->addControl(
            'price_color',
            [
                'label' => $this->l('Color'),
                'type' => ControlsManager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-price' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->addGroupControl(
            \CE\GroupControlTypography::getType(),
            [
                'name' => 'price_typography',
                'selector' => '{{WRAPPER}} .cleardeal-widget-price',
            ]
        );

        // Percentage
        $this->addControl(
            'heading_percent',
            [
                'label' => $this->l('Percentage'),
                'type' => ControlsManager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->addControl(
            'percent_color',
            [
                'label' => $this->l('Text Color'),
                'type' => ControlsManager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-percent' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->addControl(
            'percent_bg_color',
            [
                'label' => $this->l('Background Color'),
                'type' => ControlsManager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-percent' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->addGroupControl(
            \CE\GroupControlTypography::getType(),
            [
                'name' => 'percent_typography',
                'selector' => '{{WRAPPER}} .cleardeal-widget-percent',
            ]
        );

        $this->addResponsiveControl(
            'percent_padding',
            [
                'label' => $this->l('Padding'),
                'type' => ControlsManager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-percent' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->addControl(
            'percent_border_radius',
            [
                'label' => $this->l('Border Radius'),
                'type' => ControlsManager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-percent' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->endControlsSection();

        // =====================================================================
        // STYLE SECTION: ICON
        // =====================================================================
        $this->startControlsSection(
            'section_style_icon',
            [
                'label' => $this->l('Icon'),
                'tab' => ControlsManager::TAB_STYLE,
            ]
        );

        $this->addControl(
            'icon_color',
            [
                'label' => $this->l('Color'),
                'type' => ControlsManager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .cleardeal-widget-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->addResponsiveControl(
            'icon_size',
            [
                'label' => $this->l('Size'),
                'type' => ControlsManager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 8,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .cleardeal-widget-icon img' => 'width: {{SIZE}}{{UNIT}}; height: auto;',
                ],
            ]
        );

        $this->endControlsSection();

        // =====================================================================
        // STYLE SECTION: TOOLTIP
        // =====================================================================
        $this->startControlsSection(
            'section_style_tooltip',
            [
                'label' => $this->l('Tooltip'),
                'tab' => ControlsManager::TAB_STYLE,
            ]
        );

        $this->addResponsiveControl(
            'tooltip_width',
            [
                'label' => $this->l('Width'),
                'type' => ControlsManager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-tooltip' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->addControl(
            'tooltip_bg_color',
            [
                'label' => $this->l('Background Color'),
                'type' => ControlsManager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-tooltip' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .cleardeal-widget-tooltip::after' => 'border-top-color: {{VALUE}};',
                ],
            ]
        );

        $this->addControl(
            'tooltip_text_color',
            [
                'label' => $this->l('Text Color'),
                'type' => ControlsManager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-tooltip' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->addGroupControl(
            \CE\GroupControlTypography::getType(),
            [
                'name' => 'tooltip_typography',
                'selector' => '{{WRAPPER}} .cleardeal-widget-tooltip',
            ]
        );

        $this->addResponsiveControl(
            'tooltip_padding',
            [
                'label' => $this->l('Padding'),
                'type' => ControlsManager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-tooltip' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->addControl(
            'tooltip_border_radius',
            [
                'label' => $this->l('Border Radius'),
                'type' => ControlsManager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .cleardeal-widget-tooltip' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->endControlsSection();
    }

    protected function render()
    {
        $settings = $this->getSettingsForDisplay();

        // Get product from context
        $product = null;
        if (isset($GLOBALS['smarty']->tpl_vars['product'])) {
            $product = $GLOBALS['smarty']->tpl_vars['product']->value;
        }

        if (!$product) {
            $context = \Context::getContext();
            if (isset($context->controller) && method_exists($context->controller, 'getProduct')) {
                $product = $context->controller->getProduct();
            }
        }

        if (!$product && \Tools::getValue('id_product')) {
            $product = new \Product((int) \Tools::getValue('id_product'), false, \Context::getContext()->language->id);
        }

        if (!$product) {
            return;
        }

        // Convert to array
        $product_data = (array) $product;
        if (!isset($product_data['id_product']) && isset($product->id)) {
            $product_data['id_product'] = $product->id;
        }

        // Get module
        $module = \Module::getInstanceByName('cleardeal');
        if (!$module) {
            return;
        }

        // Prepare overrides
        $overrides = [];
        $overrides['days'] = $settings['days'];

        if ($settings['display_mode'] !== 'default') {
            $overrides['display_mode'] = $settings['display_mode'];
        }
        if ($settings['price_type'] !== 'default') {
            $overrides['price_type'] = $settings['price_type'];
        }
        if ($settings['show_percent'] !== 'default') {
            $overrides['show_percent'] = ($settings['show_percent'] === 'yes');
        }
        if (!empty($settings['custom_label'])) {
            $overrides['label'] = $settings['custom_label'];
        }

        // Get data
        $data = $module->getClearDealData($product_data, 'product', $overrides);

        if (!$data) {
            return;
        }

        // Determine icon visibility
        $show_icon = $settings['show_icon'];
        if ($show_icon === 'default') {
            $show_icon = \Configuration::get('CLEARDEAL_SHOW_ICON') ? 'yes' : 'no';
        }

        // Build icon HTML
        $icon_html = '';
        if ($show_icon === 'yes') {
            $icon_type = $settings['icon_type'];
            if ($icon_type === 'default') {
                $icon_type = \Configuration::get('CLEARDEAL_ICON_TYPE') ?: 'material';
            }

            if ($icon_type === 'file' && !empty($settings['icon_image']['url'])) {
                $icon_html = '<img src="' . $settings['icon_image']['url'] . '" alt="">';
            } elseif ($icon_type === 'file' && \Configuration::get('CLEARDEAL_ICON_IMAGE')) {
                $icon_html = '<img src="' . _MODULE_DIR_ . 'cleardeal/views/img/' . \Configuration::get('CLEARDEAL_ICON_IMAGE') . '" alt="">';
            } else {
                $icon_class = ($settings['icon_type'] === 'material' && !empty($settings['icon_class']))
                    ? $settings['icon_class']
                    : (\Configuration::get('CLEARDEAL_ICON_CLASS') ?: 'info');
                $icon_html = '<i class="material-icons">' . htmlspecialchars($icon_class) . '</i>';
            }

            // Add tooltip
            $tooltip = $settings['tooltip_text'];
            if (empty($tooltip)) {
                $tooltip = \Configuration::get('CLEARDEAL_ICON_TOOLTIP', \Context::getContext()->language->id);
            }
            if ($tooltip && strpos($tooltip, '%s') !== false) {
                $tooltip = sprintf($tooltip, $settings['days']);
            }

            if ($icon_html && $tooltip) {
                $icon_html = '<span class="cleardeal-widget-icon">' . $icon_html . '<span class="cleardeal-widget-tooltip">' . htmlspecialchars($tooltip) . '</span></span>';
            } elseif ($icon_html) {
                $icon_html = '<span class="cleardeal-widget-icon">' . $icon_html . '</span>';
            }
        }

        $icon_position = $settings['icon_position'] ?: 'start';

        // Output
        echo '<div class="cleardeal-widget-wrapper">';
        echo '<div class="cleardeal-widget-content cleardeal-widget-icon-' . $icon_position . '">';

        if ($icon_position === 'start') {
            echo $icon_html;
        }

        echo '<span class="cleardeal-widget-label">' . $data['label'] . '</span>';
        echo '<span class="cleardeal-widget-price">' . $data['lowest_price_formatted'] . '</span>';

        if ($data['percentage'] !== null) {
            $percent_class = $data['is_negative'] ? 'cleardeal-widget-percent-negative' : 'cleardeal-widget-percent-positive';
            echo '<span class="cleardeal-widget-percent ' . $percent_class . '">';
            echo ($data['percentage'] > 0 ? '+' : '') . $data['percentage'] . '%';
            echo '</span>';
        }

        if ($icon_position === 'end') {
            echo $icon_html;
        }

        echo '</div>';
        echo '</div>';
    }
}
