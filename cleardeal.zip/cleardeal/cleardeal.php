<?php
/**
 * ClearDeal - EU Omnibus Directive Compliance
 *
 * Displays the lowest price from a specified period.
 * Compatible with PrestaShop 8.x and 9.x
 *
 * @author    Marcin Gajewski <kontakt@marcingajewski.pl>
 * @copyright 2025 marcingajewski.pl
 * @license   https://marcingajewski.pl
 * @version   1.0.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/classes/ClearDealPriceHistory.php';

class ClearDeal extends Module
{
    public function __construct()
    {
        $this->name = 'cleardeal';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'marcingajewski.pl';
        $this->need_instance = 0;
        $this->bootstrap = true;

        $this->ps_versions_compliancy = ['min' => '8.0.0', 'max' => '9.99.99'];
        $this->php_version_compliancy = ['min' => '8.1.0'];

        parent::__construct();

        $this->displayName = $this->l('ClearDeal - Lowest Price');
        $this->description = $this->l('Ensures compliance with the EU Omnibus Directive by displaying the lowest price from a specified period.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall? All price history logs will be deleted.');
    }

    public function install()
    {
        return parent::install()
            && $this->installDb()
            && $this->installTabs()
            && $this->registerHooks()
            && $this->setDefaultConfig();
    }

    public function uninstall()
    {
        return parent::uninstall()
            && $this->uninstallTabs()
            && $this->uninstallDb()
            && $this->deleteConfig();
    }

    private function installDb()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'cleardeal_price_history` (
            `id_history` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_product` INT(11) UNSIGNED NOT NULL,
            `id_product_attribute` INT(11) UNSIGNED NOT NULL DEFAULT 0,
            `price_tax_incl` DECIMAL(20, 6) NOT NULL,
            `price_tax_excl` DECIMAL(20, 6) NOT NULL,
            `id_shop` INT(11) UNSIGNED NOT NULL,
            `id_currency` INT(11) UNSIGNED NOT NULL,
            `id_country` INT(11) UNSIGNED NOT NULL,
            `id_group` INT(11) UNSIGNED NOT NULL,
            `captured_at` DATETIME NOT NULL,
            PRIMARY KEY (`id_history`),
            INDEX `idx_product` (`id_product`, `id_product_attribute`),
            INDEX `idx_captured_at` (`captured_at`),
            INDEX `idx_lookup` (`id_product`, `id_product_attribute`, `id_shop`, `id_currency`, `captured_at`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

        return Db::getInstance()->execute($sql);
    }

    private function uninstallDb()
    {
        return Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'cleardeal_price_history`');
    }

    private function installTabs()
    {
        // Step 1: Find or create Secret Sauce parent tab
        $improve_id = (int) Tab::getIdFromClassName('IMPROVE');
        if (!$improve_id) {
            $improve_id = (int) Tab::getIdFromClassName('AdminParentModulesSf');
        }
        if (!$improve_id) {
            $improve_id = 0;
        }

        $secret_sauce_class = 'AdminSecretSauce';
        $secret_sauce_id = (int) Tab::getIdFromClassName($secret_sauce_class);

        // Create Secret Sauce if it doesn't exist
        if (!$secret_sauce_id) {
            $secretSauce = new Tab();
            $secretSauce->active = 1;
            $secretSauce->class_name = $secret_sauce_class;
            $secretSauce->id_parent = $improve_id;
            $secretSauce->module = ''; // Important: No owner!
            if (property_exists($secretSauce, 'icon')) {
                $secretSauce->icon = 'science';
            }
            foreach (Language::getLanguages(false) as $lang) {
                $secretSauce->name[(int) $lang['id_lang']] = 'Secret Sauce';
            }
            if (!$secretSauce->add()) {
                return false;
            }
            $secret_sauce_id = (int) $secretSauce->id;
        }

        // Step 2: Add ClearDeal tab under Secret Sauce
        $existing_id = Tab::getIdFromClassName('AdminClearDeal');
        if ($existing_id) {
            $tab = new Tab($existing_id);
            $tab->id_parent = $secret_sauce_id;
            $tab->active = 1;
            $tab->save();
        } else {
            $tab = new Tab();
            $tab->active = 1;
            $tab->class_name = 'AdminClearDeal';
            $tab->module = $this->name;
            $tab->id_parent = $secret_sauce_id;
            if (property_exists($tab, 'icon')) {
                $tab->icon = 'price_check';
            }
            foreach (Language::getLanguages(false) as $lang) {
                $tab->name[(int) $lang['id_lang']] = 'ClearDeal';
            }
            if (!$tab->add()) {
                return false;
            }
        }

        return true;
    }

    private function uninstallTabs()
    {
        // Remove ClearDeal tab
        $id_tab = (int) Tab::getIdFromClassName('AdminClearDeal');
        if ($id_tab) {
            $tab = new Tab($id_tab);
            $tab->delete();
        }

        // Remove Secret Sauce only if it has no other children
        $id_secret_sauce = (int) Tab::getIdFromClassName('AdminSecretSauce');
        if ($id_secret_sauce) {
            $children = Tab::getTabs(Context::getContext()->language->id, $id_secret_sauce);
            if (empty($children)) {
                $ss = new Tab($id_secret_sauce);
                $ss->delete();
            }
        }

        return true;
    }

    private function registerHooks()
    {
        $hooks = [
            'displayHeader',
            'actionProductAdd',
            'actionProductUpdate',
            'actionObjectSpecificPriceAddAfter',
            'actionObjectSpecificPriceUpdateAfter',
            'actionObjectSpecificPriceDeleteAfter',
            'displayProductPriceBlock',
            'displayProductAdditionalInfo',
            'displayProductListReviews',
            // Custom Hooks
            'displayClearDealProduct',
            'displayClearDealListing',
            'displayClearDealQuickView',
            // Creative Elements Hook
            'actionCreativeElementsInit',
        ];

        return $this->registerHook($hooks);
    }

    private function setDefaultConfig()
    {
        $languages = Language::getLanguages(false);

        $defaults = [
            'CLEARDEAL_DAYS' => 30,
            'CLEARDEAL_DISPLAY_MODE' => 'on-discount',
            'CLEARDEAL_PRICE_TYPE' => 'gross',
            'CLEARDEAL_SHOW_PERCENT' => 1,
            'CLEARDEAL_PRECISION' => 0,
            'CLEARDEAL_SHOW_ICON' => 1,
            'CLEARDEAL_ICON_POSITION' => 'start',
            'CLEARDEAL_ICON_TYPE' => 'material',
            'CLEARDEAL_ICON_CLASS' => 'info',
            'CLEARDEAL_ICON_IMAGE' => '',
            'CLEARDEAL_LOGGING_MODE' => 'immediate',
            'CLEARDEAL_LOG_RETENTION' => 365,
        ];

        foreach ($defaults as $key => $value) {
            Configuration::updateValue($key, $value);
        }

        // Multilingual defaults
        $label_product = [];
        $label_listing = [];
        $label_quickview = [];
        $tooltip = [];

        foreach ($languages as $lang) {
            $id = (int) $lang['id_lang'];
            $label_product[$id] = $this->l('Lowest price in last %s days:');
            $label_listing[$id] = $this->l('From %s days:');
            $label_quickview[$id] = $this->l('Lowest price (%s days):');
            $tooltip[$id] = $this->l('This is the lowest price of this product in the last %s days before the current promotion, in accordance with the EU Omnibus Directive.');
        }

        Configuration::updateValue('CLEARDEAL_LABEL_PRODUCT', $label_product);
        Configuration::updateValue('CLEARDEAL_LABEL_LISTING', $label_listing);
        Configuration::updateValue('CLEARDEAL_LABEL_QUICKVIEW', $label_quickview);
        Configuration::updateValue('CLEARDEAL_ICON_TOOLTIP', $tooltip);

        return true;
    }

    private function deleteConfig()
    {
        $keys = [
            'CLEARDEAL_DAYS',
            'CLEARDEAL_DISPLAY_MODE',
            'CLEARDEAL_PRICE_TYPE',
            'CLEARDEAL_SHOW_PERCENT',
            'CLEARDEAL_PRECISION',
            'CLEARDEAL_SHOW_ICON',
            'CLEARDEAL_ICON_POSITION',
            'CLEARDEAL_ICON_TYPE',
            'CLEARDEAL_ICON_CLASS',
            'CLEARDEAL_ICON_IMAGE',
            'CLEARDEAL_ICON_TOOLTIP',
            'CLEARDEAL_LABEL_PRODUCT',
            'CLEARDEAL_LABEL_LISTING',
            'CLEARDEAL_LABEL_QUICKVIEW',
            'CLEARDEAL_LOGGING_MODE',
            'CLEARDEAL_LOG_RETENTION',
        ];

        foreach ($keys as $key) {
            Configuration::deleteByName($key);
        }

        return true;
    }

    // =========================================================================
    // HOOKS - Creative Elements
    // =========================================================================

    public function hookActionCreativeElementsInit()
    {
        if (!file_exists(__DIR__ . '/classes/WidgetClearDeal.php')) {
            return;
        }

        require_once __DIR__ . '/classes/WidgetClearDeal.php';

        $categories = \CE\Plugin::instance()->elements_manager->getCategories();
        if (!isset($categories['secretsauce'])) {
            \CE\Plugin::instance()->elements_manager->addCategory(
                'secretsauce',
                [
                    'title' => 'Secret Sauce',
                    'icon' => 'eicon-flask',
                ]
            );
        }

        \CE\Plugin::instance()->widgets_manager->registerWidgetType(
            new \ClearDeal\Widget\WidgetClearDeal()
        );
    }

    // =========================================================================
    // HOOKS - Frontend Display
    // =========================================================================

    public function hookDisplayHeader()
    {
        $this->context->controller->addCSS($this->_path . 'views/css/front.css');

        return '';
    }

    public function hookDisplayProductPriceBlock($params)
    {
        if (!isset($params['type']) || $params['type'] !== 'after_price') {
            return '';
        }

        return $this->renderClearDealBlock($params, 'product');
    }

    public function hookDisplayProductAdditionalInfo($params)
    {
        return $this->renderClearDealBlock($params, 'product');
    }

    public function hookDisplayProductListReviews($params)
    {
        return $this->renderClearDealBlock($params, 'listing');
    }

    public function hookDisplayClearDealProduct($params)
    {
        return $this->renderClearDealBlock($params, 'product');
    }

    public function hookDisplayClearDealListing($params)
    {
        return $this->renderClearDealBlock($params, 'listing');
    }

    public function hookDisplayClearDealQuickView($params)
    {
        return $this->renderClearDealBlock($params, 'quickview');
    }

    // =========================================================================
    // HOOKS - Price Logging
    // =========================================================================

    public function hookActionProductAdd($params)
    {
        $this->logPriceChange($params['id_product'] ?? 0);
    }

    public function hookActionProductUpdate($params)
    {
        $this->logPriceChange($params['id_product'] ?? 0);
    }

    public function hookActionObjectSpecificPriceAddAfter($params)
    {
        if (isset($params['object']->id_product)) {
            $this->logPriceChange($params['object']->id_product);
        }
    }

    public function hookActionObjectSpecificPriceUpdateAfter($params)
    {
        if (isset($params['object']->id_product)) {
            $this->logPriceChange($params['object']->id_product);
        }
    }

    public function hookActionObjectSpecificPriceDeleteAfter($params)
    {
        if (isset($params['object']->id_product)) {
            $this->logPriceChange($params['object']->id_product);
        }
    }

    protected function logPriceChange($id_product)
    {
        if (!$id_product) {
            return;
        }

        $logging_mode = Configuration::get('CLEARDEAL_LOGGING_MODE');
        if ($logging_mode !== 'immediate') {
            return;
        }

        ClearDealPriceHistory::addPriceChange($id_product);
    }

    // =========================================================================
    // RENDERING
    // =========================================================================

    public function renderClearDealBlock($params, $hook_type = 'product')
    {
        $product = $params['product'] ?? null;

        // Fallback: Context Controller (Product Page)
        if (!$product && $this->context->controller instanceof ProductController) {
            $product = $this->context->controller->getProduct();
        }

        // Fallback: Smarty Variable
        if (!$product && isset($this->context->smarty->tpl_vars['product'])) {
            $product = $this->context->smarty->tpl_vars['product']->value;
        }

        if (!$product) {
            return '';
        }

        // Don't cast LazyArray to array
        if (is_object($product) && !($product instanceof \ArrayAccess)) {
            $product = (array) $product;
        }

        $data = $this->getClearDealData($product, $hook_type);

        if (!$data) {
            return '';
        }

        $this->context->smarty->assign([
            'cleardeal_data' => $data,
            'cleardeal_show_icon' => (bool) Configuration::get('CLEARDEAL_SHOW_ICON'),
            'cleardeal_icon_position' => Configuration::get('CLEARDEAL_ICON_POSITION') ?: 'start',
            'cleardeal_icon_type' => Configuration::get('CLEARDEAL_ICON_TYPE') ?: 'material',
            'cleardeal_icon_class' => Configuration::get('CLEARDEAL_ICON_CLASS') ?: 'info',
            'cleardeal_icon_image' => Configuration::get('CLEARDEAL_ICON_IMAGE'),
            'cleardeal_tooltip' => $this->getTooltipText(),
            'cleardeal_module_dir' => $this->_path,
        ]);

        return $this->display(__FILE__, 'views/templates/hook/cleardeal_price.tpl');
    }

    public function getClearDealData($product, $hook_type, $overrides = [])
    {
        if (empty($product)) {
            return null;
        }

        // Get product ID
        $id_product = 0;
        if (isset($product['id_product'])) {
            $id_product = (int) $product['id_product'];
        } elseif (isset($product['id'])) {
            $id_product = (int) $product['id'];
        }

        if (!$id_product) {
            return null;
        }

        // Get attribute ID
        $id_pa = 0;
        if ($hook_type === 'product' || $hook_type === 'quickview') {
            $id_pa = (int) Tools::getValue('id_product_attribute');
            if (!$id_pa && isset($product['id_product_attribute'])) {
                $id_pa = (int) $product['id_product_attribute'];
            }
            if (!$id_pa) {
                $id_pa = (int) Product::getDefaultAttribute($id_product);
            }
        } else {
            $id_pa = (int) ($product['id_product_attribute'] ?? 0);
        }

        // Configuration
        $price_type = $overrides['price_type'] ?? Configuration::get('CLEARDEAL_PRICE_TYPE') ?: 'gross';
        $days = (int) ($overrides['days'] ?? Configuration::get('CLEARDEAL_DAYS') ?: 30);
        $display_mode = $overrides['display_mode'] ?? Configuration::get('CLEARDEAL_DISPLAY_MODE') ?: 'on-discount';
        $show_percent = isset($overrides['show_percent']) ? $overrides['show_percent'] : (bool) Configuration::get('CLEARDEAL_SHOW_PERCENT');
        $precision = (int) Configuration::get('CLEARDEAL_PRECISION');

        // Get prices
        $use_tax = ($price_type !== 'net');
        $current = Product::getPriceStatic($id_product, $use_tax, $id_pa, 6, null, false, true);
        $regular = Product::getPriceStatic($id_product, $use_tax, $id_pa, 6, null, false, false);

        // Check if discounted
        $epsilon = 0.00001;
        $is_discounted = ($current < ($regular - $epsilon));

        // Display mode check
        if ($display_mode === 'on-discount' && !$is_discounted) {
            return null;
        }

        // Get lowest price from history
        $lowest = ClearDealPriceHistory::getLowestPrice($id_product, $id_pa, $days, $price_type);

        if (!$lowest || $lowest <= 0) {
            $lowest = $current;
        }

        // Calculate percentage change
        $percent = null;
        if ($show_percent) {
            $diff = $current - $lowest;
            if (abs($diff) > $epsilon && $lowest > 0) {
                $val = ($diff / $lowest) * 100;
                $percent = round($val, $precision);
            }
        }

        // Format price
        $low_disp = Tools::convertPrice($lowest, $this->context->currency);
        $formatted = $this->context->currentLocale->formatPrice($low_disp, $this->context->currency->iso_code);

        // Get label
        $label = $overrides['label'] ?? $this->getLabelForHook($hook_type);
        if (strpos($label, '%s') !== false) {
            $label = sprintf($label, $days);
        }

        return [
            'label' => $label,
            'lowest_price_formatted' => $formatted,
            'lowest_price_raw' => $lowest,
            'percentage' => $percent,
            'hook_type' => $hook_type,
            'is_negative' => ($percent !== null && $percent < 0),
        ];
    }

    private function getLabelForHook($hook_type)
    {
        $id_lang = $this->context->language->id;

        switch ($hook_type) {
            case 'listing':
                return Configuration::get('CLEARDEAL_LABEL_LISTING', $id_lang) ?: $this->l('From %s days:');
            case 'quickview':
                return Configuration::get('CLEARDEAL_LABEL_QUICKVIEW', $id_lang) ?: $this->l('Lowest price (%s days):');
            default:
                return Configuration::get('CLEARDEAL_LABEL_PRODUCT', $id_lang) ?: $this->l('Lowest price in last %s days:');
        }
    }

    private function getTooltipText()
    {
        $id_lang = $this->context->language->id;
        $days = Configuration::get('CLEARDEAL_DAYS') ?: 30;
        $tooltip = Configuration::get('CLEARDEAL_ICON_TOOLTIP', $id_lang);

        if ($tooltip && strpos($tooltip, '%s') !== false) {
            $tooltip = sprintf($tooltip, $days);
        }

        return $tooltip;
    }

    // =========================================================================
    // ADMIN CONFIGURATION
    // =========================================================================

    public function getContent()
    {
        // Redirect to our custom admin controller
        Tools::redirectAdmin(
            $this->context->link->getAdminLink('AdminClearDeal')
        );
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    public function getConfigValue($key, $default = null)
    {
        $value = Configuration::get($key);
        return ($value === false && $default !== null) ? $default : $value;
    }
}
